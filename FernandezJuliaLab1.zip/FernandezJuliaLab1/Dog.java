package com.lab01;

public class Dog 
{
	private String name,breed,color;
	private int ageyr,agemth,bday,bmth;
	private char gender;
	
	public Dog(String name, String breed,String color,int ageyr,int agemth,int bday,int bmth,
				char gender)
	{
		this.name=name;
		this.breed=breed;
		this.color=color;
		this.ageyr=ageyr;
		this.agemth=agemth;
		this.bday=bday;
		this.bmth=bmth;
		this.gender=gender;
		String gend;
		if(gender=='f'||gender=='F') gend="girl"; else gend="boy"; 
		System.out.println("Who's a good "+gend+"?!");
	}
	
	public String getName()
	{
		return this.name;
	}
	public String getBreed()
	{
		return this.breed;
	}
	public String getColor()
	{
		return this.color;
	}
	public int getAgeyr()
	{
		return this.ageyr;
	}
	public int getAgemth()
	{
		return this.agemth;
	}
	public int getBday()
	{
		return this.bday;
	}
	public int getBmth()
	{
		return this.bmth;
	}
	public char getGender()
	{
		return this.gender;
	}
	
	void tricks(String trck)
	{
		System.out.println("This dog knows how to "+trck+".");
	}
}
