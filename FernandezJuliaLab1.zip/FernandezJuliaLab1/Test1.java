package com.lab01;

public class Test1 
{
	public static void main(String[] args) 
	{
		Dog d1=new Dog("Tikoy","Shih Tzu","Brown",0,9,24,8,'F');
		
		System.out.println("Name: "+d1.getName());
		System.out.println("Gender: "+d1.getGender());
		System.out.println("Breed: "+d1.getBreed());
		System.out.println("Color: "+d1.getColor());
		System.out.println("Age: "+d1.getAgeyr()+" year/s and "+d1.getAgemth()+" month/s");
		System.out.println("Birthday: "+d1.getBmth()+"/"+d1.getBday());
		
		d1.tricks("fetch");
	}

}
